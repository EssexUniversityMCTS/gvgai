package shiftBufferRHGA.evodef;

/**
 * Created by sml on 08/01/2017.
 */
public interface FitnessSpace extends SolutionEvaluator, SearchSpace {
}
